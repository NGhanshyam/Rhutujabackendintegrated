package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.HomeInteriorDesigningLoanProject.app.IRepository.ApplicantRepository;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.ApplicantIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Applicant;

@Service
public class ApplicantServiceImpl implements ApplicantIService 
{

	@Autowired
	ApplicantRepository ar;
	
	@Override
	public Applicant saveApplicant(Applicant a ) {

		Applicant app = ar.save(a);
		
		return app;
	}

	@Override
	public Applicant get(int applicantId) {

		return ar.findByapplicantId(applicantId);
	}
	
	

}
