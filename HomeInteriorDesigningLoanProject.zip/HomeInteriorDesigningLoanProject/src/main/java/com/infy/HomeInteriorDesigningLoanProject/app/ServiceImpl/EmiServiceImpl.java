package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.infy.HomeInteriorDesigningLoanProject.app.IRepository.EmiRepository;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.EmiIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.EmailSender;
import com.infy.HomeInteriorDesigningLoanProject.app.model.LoanDetails;

@Service
public class EmiServiceImpl implements EmiIService{

	@Autowired
	EmiRepository er;
	
	@Override
	public LoanDetails saveLoanDetails(LoanDetails l) {

		return er.save(l);
		 
	}
	


	@Override
	public LoanDetails getByLoanId(int loanDetailId) {

	 	LoanDetails l = er.findByloanDetailId(loanDetailId);
		return l;
	}
	
	
	@Autowired
	JavaMailSender jms ;
	
	
	public void send1stEmail(MultipartFile f1 , EmailSender e) throws IOException, MessagingException
	{
		
		MimeMessage mm =jms.createMimeMessage();
		
		MimeMessageHelper mmh = new MimeMessageHelper(mm, true);
		mmh.setTo(e.getToEmail());
		mmh.setText(e.getTextMessage());
		mmh.setSubject(e.getSubject());
		mmh.addAttachment(f1.getOriginalFilename(), f1);
		jms.send(mm);
		
				
	}


}
