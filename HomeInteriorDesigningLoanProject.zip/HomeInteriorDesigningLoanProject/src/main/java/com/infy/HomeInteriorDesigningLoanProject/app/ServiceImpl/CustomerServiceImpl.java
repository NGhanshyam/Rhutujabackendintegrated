package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.infy.HomeInteriorDesigningLoanProject.app.IRepository.CustomerRepository;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.CustomerIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Customer;
import com.infy.HomeInteriorDesigningLoanProject.app.model.EmailSender;

@Service
public class CustomerServiceImpl implements CustomerIService{

	@Autowired
	CustomerRepository cr;
	
	@Override
	public Customer registerCx(Customer cust) 
	{
		Customer c = cr.save(cust);
		return c;
	}

	@Override
	public Customer getCxDatabyId(int customerId) 
	{

		Customer c = cr.findById(customerId);
		
		return c;
	}

	@Override
	public List<Customer> getAllData() {

		return cr.findAll();
	}
	

}
