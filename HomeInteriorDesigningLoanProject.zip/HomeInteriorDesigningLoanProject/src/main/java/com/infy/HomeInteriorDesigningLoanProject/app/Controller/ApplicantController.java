package com.infy.HomeInteriorDesigningLoanProject.app.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.HomeInteriorDesigningLoanProject.app.IService.ApplicantIService;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.CustomerIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Applicant;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Customer;

@RestController
@RequestMapping("/applicant")
public class ApplicantController 
{
	@Autowired
	CustomerIService cis;
	
	@Autowired
	ApplicantIService ais;
	
	@PostMapping("/saveapplicant/{customerId}")
	public Applicant saveApplicant(@RequestBody Applicant a, @PathVariable int customerId)
	{		
		Customer c = cis.getCxDatabyId(customerId);
		
		a.setCustomer(c);
		Applicant app =ais.saveApplicant(a);		
		return app;
		
	}
	
	

}
