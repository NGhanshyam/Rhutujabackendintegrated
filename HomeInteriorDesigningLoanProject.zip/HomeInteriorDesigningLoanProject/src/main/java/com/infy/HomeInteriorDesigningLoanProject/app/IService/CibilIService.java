package com.infy.HomeInteriorDesigningLoanProject.app.IService;

import com.infy.HomeInteriorDesigningLoanProject.app.model.Cibil;

public interface CibilIService {

	int regCibilScore(Cibil cibil);

}
