package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import org.springframework.stereotype.Service;

import com.infy.HomeInteriorDesigningLoanProject.app.IService.SanctionLetterI;

@Service
public class SanctionLetterImpl implements SanctionLetterI{

}
