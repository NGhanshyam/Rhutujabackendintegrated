package com.infy.HomeInteriorDesigningLoanProject.app.IService;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.HomeInteriorDesigningLoanProject.app.IRepository.EmiRepository;
import com.infy.HomeInteriorDesigningLoanProject.app.model.LoanDetails;

public interface EmiIService {

	public LoanDetails saveLoanDetails(LoanDetails l);

	public LoanDetails getByLoanId(int loanDetailId);
}
