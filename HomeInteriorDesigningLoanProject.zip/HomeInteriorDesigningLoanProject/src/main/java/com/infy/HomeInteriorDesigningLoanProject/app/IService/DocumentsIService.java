package com.infy.HomeInteriorDesigningLoanProject.app.IService;

import com.infy.HomeInteriorDesigningLoanProject.app.model.Documents;

public interface DocumentsIService {

	void saveDoc(Documents d);

}
