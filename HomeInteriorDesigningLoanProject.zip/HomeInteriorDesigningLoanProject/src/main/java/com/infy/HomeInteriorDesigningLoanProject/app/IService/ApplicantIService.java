package com.infy.HomeInteriorDesigningLoanProject.app.IService;

import com.infy.HomeInteriorDesigningLoanProject.app.model.Applicant;

public interface ApplicantIService 
{

	Applicant saveApplicant(Applicant a);

	Applicant get(int applicantId);
	
	
	
	

}
