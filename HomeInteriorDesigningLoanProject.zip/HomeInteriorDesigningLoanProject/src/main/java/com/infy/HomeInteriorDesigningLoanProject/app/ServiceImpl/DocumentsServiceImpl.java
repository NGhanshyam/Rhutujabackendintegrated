package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.HomeInteriorDesigningLoanProject.app.IRepository.DocumentsRepository;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.DocumentsIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Documents;

@Service
public class DocumentsServiceImpl implements DocumentsIService{

	
	@Autowired
	DocumentsRepository dr;

	@Override
	public void saveDoc(Documents d) {

		dr.save(d);
	}
	
}
