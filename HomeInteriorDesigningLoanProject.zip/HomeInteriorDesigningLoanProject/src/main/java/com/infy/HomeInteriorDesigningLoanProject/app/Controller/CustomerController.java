package com.infy.HomeInteriorDesigningLoanProject.app.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.infy.HomeInteriorDesigningLoanProject.app.IService.CustomerIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Customer;


@RestController
@CrossOrigin("*")
@RequestMapping ("/customer")
public class CustomerController
{

	@Autowired
	CustomerIService cs;
	
	@PostMapping("/saveCx")
	public Customer registerCx(@RequestBody Customer cust)
	{
		Customer c = cs.registerCx(cust);
		
		return c;
	}
	
	@GetMapping("/getallcxs")
	public List<Customer> getallCustomers()
	{
		List<Customer> clist = cs.getAllData();
		return clist;
	}
	
}
