package com.infy.HomeInteriorDesigningLoanProject.app.IService;

public interface SanctionLetterI {

}
