package com.infy.HomeInteriorDesigningLoanProject.app.Controller;

import java.io.IOException;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.CustomerIService;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.EmiIService;
import com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl.CustomerServiceImpl;
import com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl.EmiServiceImpl;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Customer;
import com.infy.HomeInteriorDesigningLoanProject.app.model.EmailSender;
import com.infy.HomeInteriorDesigningLoanProject.app.model.LoanDetails;

@RestController
@RequestMapping("/emi")
public class EmiController 
{

	@Autowired
	CustomerIService cis;
	
	@Autowired
	EmiIService eis;
	
	@PostMapping(value="/calemi")
	public LoanDetails calemi(@RequestBody LoanDetails ld )
	{ 
		Float roi = ld.getAnnualInterest();
		System.out.println(roi);
		
		Long loanrequired = ld.getTotalLoanRequired();
		System.out.println(loanrequired);
		
		Integer tenure = ld.getTenureofLoan();
		System.out.println(tenure);

		 Float outstandingAmount = (loanrequired + (loanrequired * (roi/100)*tenure));
		 Float emi = outstandingAmount/tenure;
		 
		 
		 ld.setPayableLoan(outstandingAmount);

		 
		LoanDetails l =  eis.saveLoanDetails(ld);

//		 LoanDetails ld= new LoanDetails();
//		 ld.setPayableLoan(outstandingAmount);
//	
//		System.out.println(ld.getPayableLoan());
//		
//		cx.getLoandetails().getPayableLoan();
//		
//		System.out.println(cx.getLoandetails().getPayableLoan());
//		
//		Customer c = cis.registerCx(cx);
		
		return l;
		
	}
	
	
	
	
	

	
	@Value ("${spring.mail.username}")
	private String fromEmail;
	
	@Autowired
	EmiServiceImpl esimpl;
	
		
	@PostMapping(value="/sendemail/{loanDetailId}" ,consumes =MediaType.MULTIPART_FORM_DATA_VALUE)
	public String send1stEmailwithAttachment(@PathVariable int loanDetailId , @RequestPart (required = true , value = "attachment")MultipartFile f1 ,
			@RequestPart ("email") String email) throws IOException,MessagingException
	{
		
		EmailSender emailsender = new EmailSender();
		
		emailsender.setFromEmail(fromEmail);
//		LoanDetails ld1 = new LoanDetails();
		
		ObjectMapper om = new ObjectMapper();
		
		EmailSender e1 = om.readValue(email, EmailSender.class);
		
		emailsender.setToEmail(e1.getToEmail());
		emailsender.setSubject(e1.getSubject());
		
		LoanDetails ld = new LoanDetails();
		
		LoanDetails l = eis.getByLoanId(loanDetailId);
		
		emailsender.setTextMessage(e1.getTextMessage()+ " " + l.getPayableLoan());
		esimpl.send1stEmail(f1, emailsender);
		
//
//		
//		email.setTextMessage(ld.getLoanDetailId() + " " + ld.getTotalLoanRequired()+ " " + ld.getTenureofLoan()+ " " +ld.getAnnualInterest()
//		+ " " + ld.getPayableLoan());
//		
		
		return "Email sent" ;
	}
	
	
	
	
	
	
}
