package com.infy.HomeInteriorDesigningLoanProject.app.IService;

import java.util.List;

import com.infy.HomeInteriorDesigningLoanProject.app.model.Customer;

public interface CustomerIService {

	public Customer registerCx(Customer cust);
	
	public Customer getCxDatabyId(int customerId);

	public List<Customer> getAllData();

	
	
	
}
