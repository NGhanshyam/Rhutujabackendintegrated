package com.infy.HomeInteriorDesigningLoanProject.app.IRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.HomeInteriorDesigningLoanProject.app.model.LoanApprovedList;

public interface LoanApprovedListRepository extends JpaRepository<LoanApprovedList, Integer>{

	public LoanApprovedList findByLoanAid(int id);
}
