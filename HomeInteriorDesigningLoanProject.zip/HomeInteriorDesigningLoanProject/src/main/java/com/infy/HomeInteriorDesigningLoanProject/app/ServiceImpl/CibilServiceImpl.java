package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.HomeInteriorDesigningLoanProject.app.IRepository.CibilRepository;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.CibilIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Cibil;

@Service
public class CibilServiceImpl implements CibilIService{

	@Autowired
	CibilRepository cir;
	
	int no;
	
	@Override
	public int regCibilScore(Cibil cibil) {

		
		Random r = new Random();
		
		for(int i= 0 ;i<3;i++)
		{
			no = r.nextInt(999);
		}
		System.out.println(no);
		
		cibil.setCibilScore(no);

		if(cibil.getCibilScore()>=700)
		{
			cibil.setCibilstatus(1);
			cibil.setCibilremark("Eligible");
		}
		else
		{
			cibil.setCibilstatus(0);
			cibil.setCibilremark("NotEligible");

		}
		cir.save(cibil);

		return no;
	}

}
